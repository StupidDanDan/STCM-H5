//关于swiper
var swiperH = new Swiper('.swiper-container-h', {
	direction: 'vertical',
	spaceBetween: 50,
	pagination: {
		el: '.swiper-pagination-h',
		clickable: true,
	},
	// Disable preloading of all images
	preloadImages: false,
	// Enable lazy loading
	lazy: true,
	on:{

      init: function(){
        swiperAnimateCache(this); //隐藏动画元素 
        swiperAnimate(this); //初始化完成开始动画
      }, 
      slideChangeTransitionEnd: function(){ 
        swiperAnimate(this); //每个slide切换结束时也运行当前slide动画
      } 
    }
});
var swiperV = new Swiper('.swiper-container-v', {
	effect: 'flip',
	initialSlide: 0,
	spaceBetween: 50,
	pagination: {
		el: '.swiper-pagination-v',
		clickable: true,
	},
	navigation: {
		nextEl: '.swiper-button-next',
		prevEl: '.swiper-button-prev',
	},

});
